const header=document.querySelector("header");

window.addEventListener("scroll", function(){
    header.classList.toggle("sticky", this.window.scrollY>0);
})

let menu=document.querySelector('#menu-icon');
let navmenu=document.querySelector('.navmenu');

menu.onclick=()=>{
    menu.classList.toggle('bx-x');
    menu.classList.toggle('open');
}

let totalAmount = 0; 
const cartItemsContainer = document.getElementById('cart-items'); 

function addItem(button) {
    const priceElement = button.parentElement.querySelector('.price p');
    const priceText = priceElement.textContent;
    const priceValue = parseFloat(priceText.replace('$', '')); 
    
    const nameElement = button.parentElement.querySelector('.price h4'); 
    const itemName = nameElement.textContent;
    
    totalAmount += priceValue;

    const totalPriceElement = document.querySelector('#total-price');
    totalPriceElement.textContent = totalAmount.toFixed(2); 

    const cartItem = document.createElement('div');
    cartItem.classList.add('cart-item');
    cartItem.innerHTML = `
        <span>${itemName} - ${priceText}</span>
        <button class="delete-button" onclick="removeItem(this)">Delete</button>
    `;

    cartItemsContainer.appendChild(cartItem);

    const cartSection = document.querySelector("#cart-section");
    cartSection.style.display = "block";
}

function removeItem(button) {
    const cartItem = button.parentElement; 
    const itemText = cartItem.querySelector('span').textContent; 
    const priceText = itemText.split('-')[1].trim(); 
    const priceValue = parseFloat(priceText.replace('$', '')); 

    totalAmount -= priceValue;

    const totalPriceElement = document.querySelector('#total-price');
    totalPriceElement.textContent = totalAmount.toFixed(2);

    cartItem.remove();

    if (cartItemsContainer.children.length === 0) {
        const cartSection = document.querySelector("#cart-section");
        cartSection.style.display = "none";
    }
}
// search functionality
    document.addEventListener('DOMContentLoaded', function() {
        const searchIcon = document.querySelector('.search-icon');
        const searchInput = document.getElementById('search-input');

        searchIcon.addEventListener('click', function() {
            if (searchInput.style.display === 'none' || searchInput.style.display === '') {
                searchInput.style.display = 'inline-block';
                searchInput.focus();
            } else {
                searchInput.style.display = 'none';
            }
        });
        searchInput.addEventListener('keyup', function() {
            const query = searchInput.value.toLowerCase();
            const products = document.querySelectorAll('.products .row');
            let hasVisibleItems = false;
        
            products.forEach(product => {
                const productName = product.querySelector('.price h4').textContent.toLowerCase();
                if (productName.includes(query)) {
                    product.style.display = 'block'; 
                    hasVisibleItems = true; 
                } else {
                    product.style.display = 'none'; 
                }
            });
        
            const productsContainer = document.querySelector('.products');
            productsContainer.style.display = hasVisibleItems ? 'grid' : 'none';
    });
        
    });
